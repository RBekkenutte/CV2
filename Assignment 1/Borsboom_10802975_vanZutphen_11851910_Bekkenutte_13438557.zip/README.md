# CV2


The results can be reproduced by running the python.py script. The script will automatically run the different datasets, point selection techniques and sampling sizes if the wrapper function call is not commented out, otherwise it will run ICP, merge frames and visualize the end result.

Note that we moved the .py file to the root of the folder, to make the paths work, please make sure that the python.py file is in the root folder. 

In the requirements.txt all the necessary packages are stated.
